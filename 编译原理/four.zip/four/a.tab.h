#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	NUMBER	257


extern YYSTYPE yylval;
